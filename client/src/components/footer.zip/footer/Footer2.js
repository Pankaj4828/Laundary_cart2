import "./Footer2.css";
import React from "react";

function Footer2() {
  return (
    <div className="footer2">
      <p id="footer2">2021 © Laundry</p>
    </div>
  );
}

export default Footer2;
